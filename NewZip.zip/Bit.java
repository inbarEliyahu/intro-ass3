
public class Bit {

    public Bit(boolean value) {
		
	}

    public String toString() {
		return ""; //replace with relevant return statement
    }

    public boolean isOne() {
		return false; //replace with relevant return statement
    }

    public boolean lessThan(Bit digit) {
        return false; //replace with relevant return statement
	}

    public boolean lessEq(Bit digit) {
        return false; //replace with relevant return statement
	}

   public static Bit fullAdderSum(Bit A, Bit B, Bit Cin) {
       return null; //replace with relevant return statement
   }
   public static Bit fullAdderCarry(Bit A, Bit B, Bit Cin) {
	   return null; //replace with relevant return statement
   }

}
